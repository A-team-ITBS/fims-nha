document.addEventListener('DOMContentLoaded', () => {
    const loginForm = document.getElementById('loginForm');

    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            // Just for demonstration purposes
            console.log('Authentication triggered');

            // Hhandle the login logic, e.g., via fetch/axios
        });
    }
});
